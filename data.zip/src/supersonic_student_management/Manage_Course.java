/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import static supersonic_student_management.View_and_Update.jTable1;

/**
 *
 * @author ashis
 */
public class Manage_Course extends javax.swing.JFrame {

    /**
     * Creates new form Manage_Course
     */
    String currentdir = System.getProperty("user.dir");
    public Manage_Course() {
        initComponents();
        Update_Table();
        id_update.setText(null);
        id_update.setVisible(false);
    }
        public void Update_Table(){
            String currentdir = System.getProperty("user.dir");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="select * from ADMIN1.course";
            PreparedStatement pst=c.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            jTable_Course.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Course = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1_close = new javax.swing.JLabel();
        jLabel2_heading = new javax.swing.JLabel();
        Move = new javax.swing.JLabel();
        jSpinner1_hours = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1_course = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1_id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        id_update = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_Course.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_Course.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_CourseMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Course);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 57, -1, 430));

        jPanel2.setBackground(new java.awt.Color(7, 20, 28));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1_close.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1_close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1_close.setText("X");
        jLabel1_close.setToolTipText("");
        jLabel1_close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1_closeMouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1_close, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 40, 30));

        jLabel2_heading.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2_heading.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2_heading.setText("Manage Course");
        jPanel2.add(jLabel2_heading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 820, -1));

        Move.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MoveMousePressed(evt);
            }
        });
        Move.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                MoveMouseDragged(evt);
            }
        });
        jPanel2.add(Move, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 50));

        jSpinner1_hours.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jSpinner1_hours.setModel(new javax.swing.SpinnerNumberModel(4, 4, 300, 1));
        jSpinner1_hours.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jSpinner1_hours, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 100, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Hours");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Course ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jTextField1_course.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField1_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 200, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Update");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, 30));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton2.setText("Delete");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 90, 30));

        jTextField1_id.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField1_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 200, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, -1, -1));
        jPanel1.add(id_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 50, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1_closeMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jLabel1_closeMouseClicked

    private void jTable_CourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_CourseMouseClicked
        DefaultTableModel model =(DefaultTableModel)jTable_Course.getModel();
        int rowIndex = jTable_Course.getSelectedRow();
        id_update.setText(model.getValueAt(rowIndex, 0).toString());
        jTextField1_id.setText(model.getValueAt(rowIndex, 0).toString());
        jTextField1_course.setText(model.getValueAt(rowIndex,1).toString());
        //jSpinner1_hours.setValue(Integer.valueOf(jTable_Course.getValueAt(rowIndex,1).toString()));
    }//GEN-LAST:event_jTable_CourseMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //int a=Integer.parseInt((String) jSpinner1_hours.getValue());
        String currentdir = System.getProperty("user.dir");
        Object hours = jSpinner1_hours.getValue();
        if(!id_update.getText().equals(""))
        {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="update course set id="+jTextField1_id.getText()+",course='"+jTextField1_course.getText()+"',hours='"+hours+"' where id="+id_update.getText()+"";
            PreparedStatement pst=c.prepareStatement(sql);
            pst.executeUpdate();
            Update_Table();
            JOptionPane.showMessageDialog(null, "Record Updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int row = jTable_Course.getSelectedRow();
        String cell = jTable_Course.getModel().getValueAt(row,0).toString();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="delete from ADMIN1.course where id="+cell;
            PreparedStatement pst=con.prepareStatement(sql);
            pst.execute();
            jTextField1_id.setText("");
            jTextField1_course.setText("");
            jSpinner1_hours.setValue(null);
            JOptionPane.showMessageDialog(null,"Delete");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Delete");
        }
        Update_Table();
    }//GEN-LAST:event_jButton2ActionPerformed
 int xx,xy;
    
    private void MoveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMousePressed

        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_MoveMousePressed

    private void MoveMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMouseDragged
        // TODO add your handling code here:
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_MoveMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Manage_Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Manage_Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Manage_Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Manage_Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage_Course().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Move;
    private javax.swing.JTextField id_update;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel1_close;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel2_heading;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1_hours;
    private javax.swing.JTable jTable_Course;
    private javax.swing.JTextField jTextField1_course;
    private javax.swing.JTextField jTextField1_id;
    // End of variables declaration//GEN-END:variables
}
