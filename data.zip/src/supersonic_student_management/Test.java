/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author ashis
 */
@Entity
@Table(name = "TEST", catalog = "", schema = "TEST")
@NamedQueries({
    @NamedQuery(name = "Test.findAll", query = "SELECT t FROM Test t"),
    @NamedQuery(name = "Test.findByUsername", query = "SELECT t FROM Test t WHERE t.testPK.username = :username"),
    @NamedQuery(name = "Test.findByPassword", query = "SELECT t FROM Test t WHERE t.testPK.password = :password"),
    @NamedQuery(name = "Test.findByLoginname", query = "SELECT t FROM Test t WHERE t.loginname = :loginname")})
public class Test implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected TestPK testPK;
    @Column(name = "LOGINNAME")
    private String loginname;

    public Test() {
    }

    public Test(TestPK testPK) {
        this.testPK = testPK;
    }

    public Test(String username, String password) {
        this.testPK = new TestPK(username, password);
    }

    public TestPK getTestPK() {
        return testPK;
    }

    public void setTestPK(TestPK testPK) {
        this.testPK = testPK;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        String oldLoginname = this.loginname;
        this.loginname = loginname;
        changeSupport.firePropertyChange("loginname", oldLoginname, loginname);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (testPK != null ? testPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Test)) {
            return false;
        }
        Test other = (Test) object;
        if ((this.testPK == null && other.testPK != null) || (this.testPK != null && !this.testPK.equals(other.testPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "supersonic_student_management.Test[ testPK=" + testPK + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
