/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.*;
public class Course extends javax.swing.JFrame {

    /**
     * Creates new form Course
     */
    public Course() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1_close = new javax.swing.JLabel();
        jLabel2_heading = new javax.swing.JLabel();
        Move = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1_course = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jSpinner1_hours = new javax.swing.JSpinner();
        jButton1_Add = new javax.swing.JButton();
        jButton1_Cancel = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jTextField1_id = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(7, 20, 28));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1_close.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1_close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1_close.setText("X");
        jLabel1_close.setToolTipText("");
        jLabel1_close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1_closeMouseClicked(evt);
            }
        });
        jPanel1.add(jLabel1_close, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 40, 30));

        jLabel2_heading.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2_heading.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2_heading.setText("Course");
        jPanel1.add(jLabel2_heading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 400, -1));

        Move.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MoveMousePressed(evt);
            }
        });
        Move.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                MoveMouseDragged(evt);
            }
        });
        jPanel1.add(Move, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 50));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("ID");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, -1));

        jTextField1_course.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(jTextField1_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 200, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Hours");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jSpinner1_hours.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jSpinner1_hours.setModel(new javax.swing.SpinnerNumberModel(4, 4, 300, 1));
        jSpinner1_hours.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(jSpinner1_hours, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 100, -1));

        jButton1_Add.setBackground(new java.awt.Color(255, 255, 255));
        jButton1_Add.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1_Add.setText("Add Course");
        jButton1_Add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1_AddActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1_Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 130, 30));

        jButton1_Cancel.setBackground(new java.awt.Color(255, 255, 255));
        jButton1_Cancel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1_Cancel.setText("Cancel");
        jButton1_Cancel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1_Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1_CancelActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1_Cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, -1, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("View and Update Course");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 210, 220, 20));

        jTextField1_id.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(jTextField1_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 13, 200, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Course ");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Add score");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 180, 20));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 400, 250));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1_closeMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jLabel1_closeMouseClicked

    private void jButton1_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1_CancelActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1_CancelActionPerformed

    private void jButton1_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1_AddActionPerformed
        // TODO add your handling code here:
        String currentdir = System.getProperty("user.dir");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            PreparedStatement ps=con.prepareStatement("insert into ADMIN1.COURSE values(?,?,?)");
            ps.setString(1,jTextField1_id.getText());
            ps.setString(2,jTextField1_course.getText());
            ps.setInt(3, (int) jSpinner1_hours.getValue());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Course Added");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,"Error" +e);
        }
    }//GEN-LAST:event_jButton1_AddActionPerformed

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        new Manage_Course().setVisible(true);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        new Add_score().setVisible(true);
    }//GEN-LAST:event_jLabel5MouseClicked
 int xx,xy;
    private void MoveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMousePressed
        // TODO add your handling code here:
        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_MoveMousePressed

    private void MoveMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMouseDragged
        // TODO add your handling code here:
                int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_MoveMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Course.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Course().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Move;
    private javax.swing.JButton jButton1_Add;
    private javax.swing.JButton jButton1_Cancel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel1_close;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel2_heading;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSpinner jSpinner1_hours;
    private javax.swing.JTextField jTextField1_course;
    private javax.swing.JTextField jTextField1_id;
    // End of variables declaration//GEN-END:variables

    void courseId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
