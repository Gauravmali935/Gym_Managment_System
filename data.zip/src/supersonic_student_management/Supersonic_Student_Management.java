/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;
//import java.sql.*;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import javax.swing.JOptionPane;
//import javax.swing.JTable;
//import net.proteanit.sql.DbUtils;
/**
 *
 * @author ashis
 */
public class Supersonic_Student_Management {

    /**
//     * @param TableSupply
     * @param args the command line arguments
     */
//    public void DisplayTableRec(JTable TableSupply)
//    {
//        try {
//            Class.forName("org.apache.derby.jdbc.ClientDriver");
//            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:C:\\Users\\ashis\\.netbeans-derby\\sm","admin1","admin1");
//            PreparedStatement ps=con.prepareStatement("select *from ADMIN1.STUDENT ");
//            ResultSet rs=ps.executeQuery();
//            TableSupply.setModel(DbUtils.resultSetToTableModel(rs));
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null,e);
//        }
//    }
    public static void main(String[] args) {
        // TODO code application logic here
        new Login().setVisible(true);
    }

//    void DisplayTableRec(JTable jTable2, String string) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
