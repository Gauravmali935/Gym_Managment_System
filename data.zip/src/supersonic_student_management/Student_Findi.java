/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author ashis
 */

public class Student_Findi {
            String currentdir = System.getProperty("user.dir");

        public void Update_Table(JTable table, String valueToSearch){
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="select * from ADMIN1.STUDENT";
            PreparedStatement pst=c.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            View_and_Update.jTable1.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        }
}
