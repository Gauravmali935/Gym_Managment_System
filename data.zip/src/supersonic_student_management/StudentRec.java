/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author ashis
 */
public class StudentRec {
            String currentdir = System.getProperty("user.dir");

     public void DisplayTableRec(JTable TableSupply)
    {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            PreparedStatement ps=con.prepareStatement("select *from ADMIN1.STUDENT ");
            ResultSet rs=ps.executeQuery();
            TableSupply.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,e);
        }
    }

    void DisplayTableRec(JTable jTable1, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public void con()
    {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void fillCourseCombo(JComboBox combo)
    {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            PreparedStatement ps;
            ps = con.prepareStatement("select * from ADMIN1.course");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                combo.addItem(rs.getString(2));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public int getCourseId(String course)
    {
        int courseId=0;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            //String sql="select * from course";
            PreparedStatement ps=c.prepareStatement("select *from course where course=?");
            ps.setString(1,course);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                courseId = rs.getInt("id");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return courseId;
    }
    public void courseadd( Integer sid,Integer cid, Integer scr )
    {
        PreparedStatement ps;
//         char i = 0;
//        if(operation == i)
//        {
        try {
             Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            ps=c.prepareStatement("insert into score values(?,?,?)");
            ps.setInt(1,sid);
            ps.setInt(2,cid);
            ps.setDouble(3, scr);
            ps.execute();
            JOptionPane.showMessageDialog(null,"Record inserted");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void courseupdate(Integer sid,Integer cid, double scr, Integer id)
    {
        PreparedStatement ps;
             try {
             Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            ps=c.prepareStatement("update score set id=?,course=?,score=? where id=?");
            ps.setInt(1,sid);
            ps.setInt(2,cid);
            ps.setDouble(3, scr);
            ps.execute();
            JOptionPane.showMessageDialog(null,"Record inserted");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }   
    }
}
