/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.*;
import net.proteanit.sql.DbUtils;
import static supersonic_student_management.View_and_Update.jTable1;
/**
 *
 * @author ashis
 */
public class Add_score extends javax.swing.JFrame {

    /**
     * Creates new form Add_score
     */
    StudentRec s = new StudentRec();
    public Add_score() {
        initComponents();
        s.fillCourseCombo(jComboBox1_Course);
        Update_Table();
        HideColumn(3);
        HideColumn(4);
        HideColumn(5);
        HideColumn(6);
    }
        public void Update_Table(){
            String currentdir = System.getProperty("user.dir");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="select * from ADMIN1.STUDENT order by id";
            PreparedStatement pst=c.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            jTable_Score.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
        public void HideColumn(int colIndex)
        {
            TableColumn col = jTable_Score.getColumnModel().getColumn(colIndex);
            col.setMaxWidth(0);
            col.setMinWidth(0);
            col.setPreferredWidth(0);
        }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Score = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel1_close1 = new javax.swing.JLabel();
        jLabel2_heading1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField1_score = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        id_update = new javax.swing.JTextField();
        jComboBox1_Course = new javax.swing.JComboBox();
        jTextField1_id = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Move = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_Score.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_Score.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ScoreMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Score);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 57, -1, 430));

        jPanel3.setBackground(new java.awt.Color(7, 20, 28));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1_close1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1_close1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1_close1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1_close1.setText("X");
        jLabel1_close1.setToolTipText("");
        jLabel1_close1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1_close1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1_close1MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel1_close1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 40, 30));

        jLabel2_heading1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2_heading1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2_heading1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2_heading1.setText("Add Score");
        jPanel3.add(jLabel2_heading1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 820, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 50));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Score");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Course ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 140, 30));

        jTextField1_score.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1_score.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField1_score, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 200, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Student ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 30));
        jPanel1.add(id_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 50, 30));

        jPanel1.add(jComboBox1_Course, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 200, -1));

        jTextField1_id.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField1_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 200, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("View and update!");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 200, 40));

        Move.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MoveMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MoveMousePressed(evt);
            }
        });
        Move.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                MoveMouseDragged(evt);
            }
        });
        jPanel1.add(Move, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 360, 490));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTable_ScoreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ScoreMouseClicked
        DefaultTableModel model =(DefaultTableModel)jTable_Score.getModel();
        int rowIndex = jTable_Score.getSelectedRow();
        jTextField1_id.setText(model.getValueAt(rowIndex, 0).toString());
        //jSpinner1_hours.setValue(Integer.valueOf(jTable_Course.getValueAt(rowIndex,1).toString()));
    }//GEN-LAST:event_jTable_ScoreMouseClicked

    private void jLabel1_close1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1_close1MouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jLabel1_close1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int id = Integer.valueOf(jTextField1_id.getText());
        @SuppressWarnings("UnnecessaryBoxing")
        int cor = Integer.valueOf(s.getCourseId(jComboBox1_Course.getSelectedItem().toString()));
        int scr = Integer.valueOf(jTextField1_score.getText());
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:C:\\Users\\ashis\\.netbeans-derby\\student_management","admin1","admin1");
            String sql="insert into score values(?,?,?)";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setInt(1,id);
            pst.setInt(2,cor);
            pst.setInt(3,scr);
            pst.execute();
            JOptionPane.showMessageDialog(null,"Added");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
        Update_Table();
//        int stdid = Integer.valueOf(jTextField1_id.getText());
//        int crsid = Integer.valueOf(s.getCourseId(jComboBox1_Course.getSelectedItem().toString()));
//        s.courseadd(stdid, crsid, scr);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        new course_update().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel4MouseClicked
int xx,xy;
    private void MoveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMouseClicked
       
    }//GEN-LAST:event_MoveMouseClicked

    private void MoveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMousePressed
        // TODO add your handling code here:
                xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_MoveMousePressed

    private void MoveMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MoveMouseDragged
        // TODO add your handling code here:
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_MoveMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Add_score.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Add_score.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Add_score.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Add_score.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_score().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Move;
    private javax.swing.JTextField id_update;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox jComboBox1_Course;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel1_close1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel2_heading1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Score;
    private javax.swing.JTextField jTextField1_id;
    private javax.swing.JTextField jTextField1_score;
    // End of variables declaration//GEN-END:variables
}
