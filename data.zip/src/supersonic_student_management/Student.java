/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTable;

public class Student {
    public static boolean email_validation(String email)
    {
        boolean status = false;
        String email_pattern = "^[a-zA-Z0-9_+&*-] + (?:\\\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\\\.) + [a-zA-Z]{2, 7} ";
        
        Pattern pattern = Pattern.compile(email_pattern);
        Matcher matcher = pattern.matcher(email);
        
        if(matcher.matches())
        {
            status = true;
        }else{
            status = false;
        }
        return status;
    }
    public void fillStudentJtable(JTable table, String valueToSearch)
    {
        
    }
}
