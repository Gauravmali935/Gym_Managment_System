/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ashis
 */
public class MyFucnction {
    String currentdir = System.getProperty("user.dir");
    public static int countData(String tableName) throws ClassNotFoundException, SQLException
    {
        int total = 0;
        
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection con=DriverManager.getConnection("jdbc:derby:C:\\Users\\ashis\\.netbeans-derby\\sm","admin1","admin1");
            try {
            Statement st;
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select count(*) as 'total' from "+tableName);
            while(rs.next())
            {
                total = rs.getInt(1);
            }
        } catch (Exception e) {
        }
            return total;
    }
    
}
