/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supersonic_student_management;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author ashis
 */
public class Setting extends javax.swing.JFrame {

    /**
     * Creates new form Setting
     */
    String currentdir = System.getProperty("user.dir");
    Login l=new Login();
    public Setting() {
        initComponents();
        data();
    }
    public void data()
    {
       PreparedStatement ps;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            java.sql.Connection c=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\student_management","admin1","admin1");
            String sql="select *from users "; 
            ps = c.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
             show_name1.setText(rs.getString("firstname"));
             show_lastname1.setText(rs.getString("lastname"));
             show_username.setText(rs.getString("username"));
             show_password.setText(rs.getString("password"));
             show_email.setText(rs.getString("email"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1_close = new javax.swing.JLabel();
        jLabel2_heading = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1_firstname = new javax.swing.JLabel();
        jLabel2_lastname = new javax.swing.JLabel();
        jLabel3_username = new javax.swing.JLabel();
        jLabel4_password = new javax.swing.JLabel();
        show_email = new javax.swing.JLabel();
        jLabel6_email = new javax.swing.JLabel();
        show_name1 = new javax.swing.JLabel();
        show_lastname1 = new javax.swing.JLabel();
        show_username = new javax.swing.JLabel();
        show_password = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(7, 20, 28));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1_close.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1_close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1_close.setText("X");
        jLabel1_close.setToolTipText("");
        jLabel1_close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1_closeMouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1_close, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, 40, 30));

        jLabel2_heading.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2_heading.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2_heading.setText("Account Setting");
        jPanel2.add(jLabel2_heading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 340, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 50));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1_firstname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1_firstname.setText("First Name");
        jPanel1.add(jLabel1_firstname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel2_lastname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2_lastname.setText("Last Name");
        jPanel1.add(jLabel2_lastname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jLabel3_username.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3_username.setText("User Name");
        jPanel1.add(jLabel3_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jLabel4_password.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4_password.setText("Password");
        jPanel1.add(jLabel4_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 90, -1));

        show_email.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(show_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 180, 20));

        jLabel6_email.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6_email.setText("E-Mali");
        jPanel1.add(jLabel6_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 60, -1));

        show_name1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(show_name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 170, 20));

        show_lastname1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(show_lastname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 170, 20));

        show_username.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(show_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 180, 20));

        show_password.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(show_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 180, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 340, 390));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1_closeMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jLabel1_closeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Setting().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1_close;
    private javax.swing.JLabel jLabel1_firstname;
    private javax.swing.JLabel jLabel2_heading;
    private javax.swing.JLabel jLabel2_lastname;
    private javax.swing.JLabel jLabel3_username;
    private javax.swing.JLabel jLabel4_password;
    private javax.swing.JLabel jLabel6_email;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel show_email;
    private javax.swing.JLabel show_lastname1;
    private javax.swing.JLabel show_name1;
    private javax.swing.JLabel show_password;
    private javax.swing.JLabel show_username;
    // End of variables declaration//GEN-END:variables
}
